package cucumberserenity.steps;


import cucumber.api.java.en.*;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Open;
import org.junit.Test;
import screenplay.tasks.Login;

import static net.serenitybdd.screenplay.GivenWhenThen.givenThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;

public class DefinitionSteps {

    Actor anna;
    public DefinitionSteps()
    {
        anna = theActorCalled("anna");
    }

    @Test
    public void myTest()
    {
        givenThat(anna).attemptsTo(Open.url("http://testmaster.vn/admin"));
    }

    @Given("^The login page is showed$")
    public void the_login_page_is_showed() {
        anna.attemptsTo(
                Open.url("http://testmaster.vn/admin")
        );
    }

    @When("^The User attempt to login with \"([^\"]*)\" and \"([^\"]*)\"$")
    public void the_user_attempt_to_login_with_something_and_something(String username, String password) {
        anna.attemptsTo(
                Login.withUserName(username).andPassword(password)
        );
    }

    @Then("^The Homepage will be showed up$")
    public void the_homepage_will_be_showed_up() {
    }

    @And("^The User confirmed with OTP code from his Email$")
    public void the_user_confirmed_with_otp_code_from_his_email() {
    }

}
