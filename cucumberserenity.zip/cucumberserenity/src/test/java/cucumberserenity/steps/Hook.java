package cucumberserenity.steps;

import cucumber.api.java.Before;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;

public class Hook {
    @Managed
    WebDriver herDriver;

    @Before
    public void Before()
    {
        OnStage.setTheStage(new OnlineCast()); //Khoi tao driver
    }
}
