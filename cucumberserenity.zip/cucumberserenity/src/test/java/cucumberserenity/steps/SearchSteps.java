package cucumberserenity.steps;

import cucumber.api.java.en.*;
import net.serenitybdd.core.pages.WebElementFacade;
import net.serenitybdd.screenplay.Actor;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import screenplay.ui.LoginPage;

import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.thucydides.core.webdriver.ThucydidesWebDriverSupport.getDriver;

public class SearchSteps {
    WebDriver driver;
    //Actor jaime;
    public SearchSteps()
    {
        this.driver = getDriver();
        //this.jaime = theActorCalled("jaime");
    }
    @Given("^The google homepage is showed$")
    public void the_google_homepage_is_showed() throws Throwable {
        this.driver.get("https://www.google.com.vn/");
    }

    @When("^The user attempt to search with the keyword is \"([^\"]*)\"$")
    public void the_user_attempt_to_search_with_the_keyword_is_something(String keyword) {
        WebElement txtSearch = this.driver.findElement(By.name("q"));
        //WebElementFacade txtSearch = LoginPage.PASSWORD.resolveFor(jaime);
        txtSearch.sendKeys(keyword);
        txtSearch.sendKeys(Keys.ENTER);
    }

    @Then("^The keyword \"([^\"]*)\" is showed on web title$")
    public void the_keyword_something_is_showed_on_web_title(String strArg1) throws Throwable {
        Assert.assertEquals(this.driver.getTitle(), "");
    }
}
